using System;
using System.Collections.Generic;

namespace Lab01
{
    // Xây dựng lớp xử lý mảng số nguyên
    class MangSoNguyen
    {
        private int[] mang = new int[0];

        // 1. Phương thức nhập mảng gồm n phần tử
        public void NhapMang()
        {
            Console.Write("Nhap so luong phan tử n: ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Gia tri khong hop le. Vui lòng nhập lai n (> 0): ");
            }

            mang = new int[n];
            Console.WriteLine($"Nhập giá trị cho {n} phần tử:");
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Phan tu thu {i + 1}: ");
                while (!int.TryParse(Console.ReadLine(), out mang[i]))
                {
                    Console.Write($"Gia tri khong hop le. Nhập lai phan tu thu {i + 1}: ");
                }
            }
        }

        // 2. Phương thức in mảng ra màn hình
        public void InMang()
        {
            if (mang.Length == 0)
            {
                Console.WriteLine("Mang rong!");
                return;
            }
            Console.WriteLine("Cac phan tu trong mang la: " + string.Join(" ", mang));
        }

        // 3. Phương thức tìm phần tử lớn nhất và nhỏ nhất trong mảng (dùng out)
        public void TimMaxMin(out int max, out int min)
        {
            max = mang[0];
            min = mang[0];
            for (int i = 1; i < mang.Length; i++)
            {
                if (mang[i] > max) max = mang[i];
                if (mang[i] < min) min = mang[i];
            }
        }

        // Hàm phụ trợ kiểm tra số nguyên tố
        private bool LaSoNguyenTo(int x)
        {
            if (x < 2) return false;
            for (int i = 2; i <= Math.Sqrt(x); i++)
            {
                if (x % i == 0) return false;
            }
            return true;
        }

        // 4. Phương thức trả về mảng các số nguyên tố
        public int[] LayCacSoNguyenTo()
        {
            List<int> dsNguyenTo = new List<int>();
            foreach (int x in mang)
            {
                if (LaSoNguyenTo(x))
                {
                    dsNguyenTo.Add(x);
                }
            }
            return dsNguyenTo.ToArray();
        }
    }

    class Bai15
    {
        public static void ChayBai15()
        {
            Console.WriteLine("=== XU LY MANG SO NGUYEN (BAI 15) ===");
            
            MangSoNguyen obj = new MangSoNguyen();

            // Gọi phương thức nhập mảng
            obj.NhapMang();

            // In mảng
            Console.WriteLine("\n--- KET QUA ---");
            obj.InMang();

            // Tìm Max, Min
            obj.TimMaxMin(out int max, out int min);
            Console.WriteLine($"Phan tu LON NHAT trong mang: {max}");
            Console.WriteLine($"Phan tu NHO NHAT trong mang: {min}");

            // Lấy và in mảng các số nguyên tố
            int[] mangNT = obj.LayCacSoNguyenTo();
            if (mangNT.Length > 0)
            {
                Console.WriteLine("Cac so nguyen tố co trong mang: " + string.Join(" ", mangNT));
            }
            else
            {
                Console.WriteLine("Trong mang khong co so nguyen to nao.");
            }
        }
    }
}