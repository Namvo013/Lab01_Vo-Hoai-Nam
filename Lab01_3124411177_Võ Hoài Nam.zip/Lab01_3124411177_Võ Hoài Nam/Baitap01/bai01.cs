using System;

namespace Lab01
{
    class Bai01
    {
        public static void ChayBai1()
        {
            Console.Write("Nhap ho ten cua ban: ");
            // Thêm toán tử ?? "" để tránh cảnh báo null cực kỳ an toàn
            string hoTen = Console.ReadLine() ?? ""; 
            Console.WriteLine("Ho ten da nhap la: " + hoTen);
        }
    }
}