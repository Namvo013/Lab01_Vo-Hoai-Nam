using System;

namespace Lab01
{
    class Bai03
    {
        public static void ChayBai3()
        {
            // Bài 3: Thực hiện các phép toán cơ bản hoặc lũy thừa (ví dụ: tính x mũ y)
            Console.WriteLine("=== CHUONG TRINH TINH TOAN (BAI 3) ===");
            
            Console.Write("Nhap so nguyen x: ");
            int x = int.Parse(Console.ReadLine());

            Console.Write("Nhap so nguyen y: ");
            int y = int.Parse(Console.ReadLine());

            // Tính x^y bằng hàm Math.Pow
            double ketQua = Math.Pow(x, y);
            
            Console.WriteLine($"Ket qua cua {x} mu {y} la: {ketQua}");
        }
    }
}