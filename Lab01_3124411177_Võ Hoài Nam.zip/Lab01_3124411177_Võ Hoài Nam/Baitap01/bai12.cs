using System;

namespace Lab01
{
    class Bai12
    {
        // Phương thức thành viên chuyển sang ký tự thường
        public string ChuyenThanhThuong(string s)
        {
            return s != null ? s.ToLower() : "";
        }

        // Phương thức thành viên chuyển sang ký tự hoa
        public string ChuyenThanhHoa(string s)
        {
            return s != null ? s.ToUpper() : "";
        }

        // Phương thức thành viên đếm số từ trong chuỗi
        public int DemSoTu(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return 0;
            string[] tu = s.Split(new char[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return tu.Length;
        }

        public static void ChayBai12()
        {
            Console.WriteLine("=== XU LY CHUOI NHIEU TU (BAI 12) ===");
            
            Console.Write("Nhap vao mot chuoi gom nhieu tu: ");
            string input = Console.ReadLine();

            // Khởi tạo đối tượng của lớp Bai12 để gọi các phương thức thành viên
            Bai12 xuLy = new Bai12();

            string chuoiThuong = xuLy.ChuyenThanhThuong(input);
            string chuoiHoa = xuLy.ChuyenThanhHoa(input);
            int soTu = xuLy.DemSoTu(input);

            Console.WriteLine($"\nChuoi chu thuong : {chuoiThuong}");
            Console.WriteLine($"Chuoi chu hoa    : {chuoiHoa}");
            Console.WriteLine($"Tong so tu       : {soTu}");
        }
    }
}