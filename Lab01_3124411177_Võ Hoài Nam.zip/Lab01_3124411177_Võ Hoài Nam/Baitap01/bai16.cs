using System;

namespace Lab01
{
    // Xây dựng lớp quản lý họ tên
    class QuanLyHoTen
    {
        private string[] danhSach = new string[0];

        // Phương thức nhập mảng họ tên của n người
        public void NhapDanhSach()
        {
            Console.Write("Nhap so luong nguoi (n): ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Gia tri khong hop le. Vui lòng nhập lại n (> 0): ");
            }

            danhSach = new string[n];
            Console.WriteLine($"Nhập họ tên cho {n} người:");
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhập họ tên người thứ {i + 1}: ");
                danhSach[i] = Console.ReadLine() ?? "";
            }
        }

        // Phương thức sắp xếp mảng họ tên theo thứ tự tăng dần (A-Z)
        public void SapXepTangDan()
        {
            if (danhSach.Length > 0)
            {
                Array.Sort(danhSach);
            }
        }

        // Phương thức in danh sách ra màn hình
        public void InDanhSach()
        {
            if (danhSach.Length == 0)
            {
                Console.WriteLine("Danh sách trống!");
                return;
            }

            for (int i = 0; i < danhSach.Length; i++)
            {
                Console.WriteLine($"  {i + 1}. {danhSach[i]}");
            }
        }
    }

    class Bai16
    {
        public static void ChayBai16()
        {
            Console.WriteLine("=== SAP XEP DANH SACH HO TEN (BAI 16) ===");
            
            QuanLyHoTen ql = new QuanLyHoTen();

            // Nhập danh sách
            ql.NhapDanhSach();

            // Sắp xếp tăng dần theo bảng chữ cái
            ql.SapXepTangDan();

            // In kết quả sau khi sắp xếp
            Console.WriteLine("\n--- DANH SACH SAU KHI SAP XEP TANG DAN (A - Z) ---");
            ql.InDanhSach();
        }
    }
}