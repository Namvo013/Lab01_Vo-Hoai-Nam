using System;

namespace Lab01
{
    class Bai08
    {
        // Phương thức hoán vị sử dụng tham chiếu ref
        public static void HoanVi(ref double a, ref double b)
        {
            double temp = a;
            a = b;
            b = temp;
        }

        public static void ChayBai8()
        {
            Console.WriteLine("=== HOAN VI HAI SO THUC VOI REF (BAI 8) ===");
            
            Console.Write("Nhap so thu nhat (a): ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Nhap so thu hai (b): ");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine($"\nTruoc khi hoan vi: a = {a}, b = {b}");

            // Gọi phương thức hoán vị truyền bằng ref
            HoanVi(ref a, ref b);

            Console.WriteLine($"Sau khi hoan vi: a = {a}, b = {b}");
        }
    }
}