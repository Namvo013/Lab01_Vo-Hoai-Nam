using System;

namespace Lab01
{
    class Bai05
    {
        public static void ChayBai5()
        {
            double x = 0, y = 0;
            bool daNhapXy = false; // Biến kiểm tra xem đã nhập x, y chưa
            int chon;

            do
            {
                // In ra Menu yêu cầu
                Console.WriteLine("\n================ MENU ================");
                Console.WriteLine("1. Nhap hai gia tri so thuc cho x, y");
                Console.WriteLine("2. Tinh x^y");
                Console.WriteLine("3. Tinh can bac 2 cua x va y");
                Console.WriteLine("4. Thoat");
                Console.Write("Chon chuc nang: ");

                // Đọc lựa chọn của người dùng
                if (!int.TryParse(Console.ReadLine(), out chon))
                {
                    Console.WriteLine("Loi: Vui long chon mot so nguyen hop le tu 1 den 4!");
                    continue;
                }

                switch (chon)
                {
                    case 1:
                        Console.Write("Nhap so thuc x: ");
                        while (!double.TryParse(Console.ReadLine(), out x))
                        {
                            Console.Write("Gia tri khong hop le. Nhap lai x: ");
                        }

                        Console.Write("Nhap so thuc y: ");
                        while (!double.TryParse(Console.ReadLine(), out y))
                        {
                            Console.Write("Gia tri khong hop le. Nhap lai y: ");
                        }

                        daNhapXy = true;
                        Console.WriteLine($"-> Da nhap thanh cong: x = {x}, y = {y}");
                        break;

                    case 2:
                        if (!daNhapXy)
                        {
                            Console.WriteLine("Loi: Ban chua nhap gia tri cho x va y (Chon chuc nang 1 truoc)!");
                        }
                        else
                        {
                            double ketQua = Math.Pow(x, y);
                            Console.WriteLine($"-> Ket qua {x}^{y} = {ketQua}");
                        }
                        break;

                    case 3:
                        if (!daNhapXy)
                        {
                            Console.WriteLine("Loi: Ban chua nhap gia tri cho x va y (Chon chuc nang 1 truoc)!");
                        }
                        else
                        {
                            // Kiểm tra điều kiện căn bậc 2 (số phải >= 0)
                            if (x >= 0)
                                Console.WriteLine($"-> Can bac 2 cua x ({x}) la: {Math.Sqrt(x)}");
                            else
                                Console.WriteLine($"-> Khong the tinh can bac 2 cua x ({x}) vi la so am!");

                            if (y >= 0)
                            Console.WriteLine($"-> Can bac 2 cua y ({y}) la: {Math.Sqrt(y)}");
                            else
                                Console.WriteLine($"-> Khong the tinh can bac 2 cua y ({y}) la so am!");
                        }
                        break;

                    case 4:
                        Console.WriteLine("Dang thoat chuong trinh. Tam biet!");
                        break;

                    default:
                        Console.WriteLine("Loi: Chuc nang khong ton tai. Vui long chon tu 1 den 4!");
                        break;
                }

            } while (chon != 4);
        }
    }
}