using System;

namespace Lab01
{
    class Bai07
    {
        // Phương thức kiểu bool kiểm tra số nguyên tố
        public static bool LaSoNguyenTo(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0) return false;
            }
            return true;
        }

        public static void ChayBai7()
        {
            Console.WriteLine("=== KIEM TRA SO NGUYEN TO (BAI 7) ===");
            
            Console.Write("Nhap vao mot so nguyen n: ");
            if (int.TryParse(Console.ReadLine(), out int n))
            {
                if (LaSoNguyenTo(n))
                {
                    Console.WriteLine($"So {n} LA so nguyên tố.");
                }
                else
                {
                    Console.WriteLine($"So {n} KHONG PHAI la số nguyên tố.");
                }
            }
            else
            {
                Console.WriteLine("Vui lòng nhập vào một số nguyên hợp lệ!");
            }
        }
    }
}