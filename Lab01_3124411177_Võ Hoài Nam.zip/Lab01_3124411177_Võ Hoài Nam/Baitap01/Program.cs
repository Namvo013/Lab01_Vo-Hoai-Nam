﻿using System;

namespace Lab01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== CHUONG TRINH THUC HANH C# ===");
            Console.WriteLine("----------------------------------------");

            // Gọi hàm chạy của mỗi bài 
            Bai01.ChayBai1();

            Console.WriteLine("\nNhan phim bat ky de thoat...");
            Console.ReadKey();
        }
    }
}