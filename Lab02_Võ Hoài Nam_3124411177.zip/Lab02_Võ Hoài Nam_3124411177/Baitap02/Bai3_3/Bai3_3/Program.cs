﻿using System;

namespace Baitap02
{
    delegate int SoSanh<T>(T a, T b);

    class SinhVien33
    {
        private string maSV;
        private string hoTen;
        private double diemTB;

        public SinhVien33()
        {
            maSV = "";
            hoTen = "";
            diemTB = 0;
        }

        public void Nhap()
        {
            do
            {
                Console.Write("Nhap ma sinh vien: ");
                maSV = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(maSV))
                    Console.WriteLine("Ma sinh vien khong duoc de trong!");

            } while (string.IsNullOrWhiteSpace(maSV));

            while (true)
            {
                Console.Write("Nhap ho ten: ");
                hoTen = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(hoTen))
                {
                    Console.WriteLine("Ho ten khong duoc de trong!");
                    continue;
                }

                bool hopLe = true;

                foreach (char c in hoTen)
                {
                    if (char.IsDigit(c))
                    {
                        hopLe = false;
                        break;
                    }
                }

                if (hopLe)
                    break;

                Console.WriteLine("Ho ten khong duoc chua so!");
            }

            while (true)
            {
                Console.Write("Nhap diem trung binh: ");

                if (double.TryParse(Console.ReadLine(), out diemTB) &&
                    diemTB >= 0 && diemTB <= 10)
                    break;

                Console.WriteLine("Diem phai tu 0 den 10!");
            }
        }

        public void Xuat()
        {
            Console.WriteLine("Ma SV: " + maSV);
            Console.WriteLine("Ho ten: " + hoTen);
            Console.WriteLine("Diem TB: " + diemTB);
        }

        public double DiemTB
        {
            get { return diemTB; }
        }
    }

    class SapXep33
    {
        public static void Sort<T>(T[] a, SoSanh<T> soSanh)
        {
            for (int i = 0; i < a.Length - 1; i++)
            {
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (soSanh(a[i], a[j]) > 0)
                    {
                        T temp = a[i];
                        a[i] = a[j];
                        a[j] = temp;
                    }
                }
            }
        }
    }

    class Bai33
    {
        static int SoSanhDiem(SinhVien33 a, SinhVien33 b)
        {
            return a.DiemTB.CompareTo(b.DiemTB);
        }

        static void Main()
        {
            int n;

            Console.Write("Nhap so luong sinh vien: ");

            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.WriteLine("So luong phai la so nguyen duong!");
                Console.Write("Nhap lai: ");
            }

            SinhVien33[] danhSach = new SinhVien33[n];

            Console.WriteLine("\nNHAP DANH SACH SINH VIEN");

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nSinh vien thu " + (i + 1));
                danhSach[i] = new SinhVien33();
                danhSach[i].Nhap();
            }

            Console.WriteLine("\nDANH SACH TRUOC KHI SAP XEP");

            for (int i = 0; i < n; i++)
            {
                danhSach[i].Xuat();
                Console.WriteLine();
            }

            SapXep33.Sort(danhSach, SoSanhDiem);

            Console.WriteLine("\nDANH SACH SAU KHI SAP XEP THEO DIEM TANG DAN");

            for (int i = 0; i < n; i++)
            {
                danhSach[i].Xuat();
                Console.WriteLine();
            }
        }
    }
}