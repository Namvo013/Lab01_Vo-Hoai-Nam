using System;

namespace Baitap02
{
    public class PhanSo
    {
        public double Tu { get; set; }
        public double Mau { get; set; }

        public PhanSo()
        {
            Tu = 0; Mau = 1;
        }

        public PhanSo(double tu, double mau)
        {
            if (mau == 0) throw new ArgumentException("Mau so phai khac 0", nameof(mau));
            Tu = tu; Mau = mau;
        }

        public PhanSo(PhanSo other)
        {
            if (other == null) throw new ArgumentNullException(nameof(other));
            Tu = other.Tu; Mau = other.Mau;
        }

        public static PhanSo operator +(PhanSo a, PhanSo b)
        {
            if (a == null || b == null) throw new ArgumentNullException();
            double tu = a.Tu * b.Mau + b.Tu * a.Mau;
            double mau = a.Mau * b.Mau;
            return new PhanSo(tu, mau).Reduce();
        }

        public override string ToString()
        {
            if (Math.Abs(Mau - 1.0) < 1e-9) return Tu.ToString();
            return $"{Tu}/{Mau}";
        }

        private PhanSo Reduce()
        {
            try
            {
                long a = (long)Tu;
                long b = (long)Mau;
                if (Math.Abs(Tu - a) < 1e-9 && Math.Abs(Mau - b) < 1e-9)
                {
                    long g = GCD(Math.Abs(a), Math.Abs(b));
                    a /= g; b /= g;
                    if (b < 0) { a = -a; b = -b; }
                    return new PhanSo(a, b);
                }
            }
            catch { }
            return this;
        }

        private static long GCD(long x, long y)
        {
            if (x == 0) return y;
            while (y != 0) { long t = y; y = x % y; x = t; }
            return x;
        }
    }
}
