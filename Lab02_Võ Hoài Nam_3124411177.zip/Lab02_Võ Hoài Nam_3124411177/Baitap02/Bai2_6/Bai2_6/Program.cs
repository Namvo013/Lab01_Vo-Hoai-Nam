﻿using System;

namespace Baitap02
{
    class PhanSoMoi
    {
        private double tu;
        private double mau;

        public PhanSoMoi()
        {
            tu = 0;
            mau = 1;
        }

        public PhanSoMoi(double tu, double mau)
        {
            if (mau == 0)
                throw new ArgumentException("Mau so phai khac 0");

            this.tu = tu;
            this.mau = mau;
        }

        public PhanSoMoi(PhanSoMoi p)
        {
            tu = p.tu;
            mau = p.mau;
        }

        public static PhanSoMoi operator +(PhanSoMoi p1, PhanSoMoi p2)
        {
            double tuMoi = p1.tu * p2.mau + p2.tu * p1.mau;
            double mauMoi = p1.mau * p2.mau;

            return new PhanSoMoi(tuMoi, mauMoi);
        }

        public override string ToString()
        {
            if (mau == 1)
                return tu.ToString();

            return tu + "/" + mau;
        }
    }

    class DayPhanSoMoi
    {
        private PhanSoMoi[] ds;

        public DayPhanSoMoi()
        {
            ds = new PhanSoMoi[0];
        }

        public DayPhanSoMoi(int n)
        {
            ds = new PhanSoMoi[n];

            for (int i = 0; i < n; i++)
                ds[i] = new PhanSoMoi();
        }

        public DayPhanSoMoi(DayPhanSoMoi d)
        {
            ds = new PhanSoMoi[d.ds.Length];

            for (int i = 0; i < ds.Length; i++)
                ds[i] = new PhanSoMoi(d.ds[i]);
        }

        public PhanSoMoi this[int i]
        {
            get
            {
                return ds[i];
            }
            set
            {
                ds[i] = value;
            }
        }

        public void Input()
        {
            for (int i = 0; i < ds.Length; i++)
            {
                Console.WriteLine("\nNhap phan so thu " + (i + 1));

                double tu;

                while (true)
                {
                    Console.Write("Nhap tu so: ");

                    if (double.TryParse(Console.ReadLine(), out tu))
                        break;

                    Console.WriteLine("Tu so phai la so! Vui long nhap lai.");
                }

                double mau;

                while (true)
                {
                    Console.Write("Nhap mau so: ");

                    if (!double.TryParse(Console.ReadLine(), out mau))
                    {
                        Console.WriteLine("Mau so phai la so! Vui long nhap lai.");
                        continue;
                    }

                    if (mau == 0)
                    {
                        Console.WriteLine("Mau so phai khac 0!");
                        continue;
                    }

                    break;
                }

                ds[i] = new PhanSoMoi(tu, mau);
            }
        }

        public void Output()
        {
            for (int i = 0; i < ds.Length; i++)
                Console.WriteLine("Phan so thu " + (i + 1) + ": " + ds[i]);
        }

        public PhanSoMoi Tong()
        {
            PhanSoMoi tong = new PhanSoMoi();

            for (int i = 0; i < ds.Length; i++)
                tong = tong + ds[i];

            return tong;
        }
    }

    class Bai26
    {
        static void Main()
        {
            Console.Write("Nhap so luong phan so n: ");
            int n;

            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.WriteLine("n phai la so nguyen duong! Vui long nhap lai.");
                Console.Write("Nhap so luong phan so n: ");
            }

            DayPhanSoMoi ds = new DayPhanSoMoi(n);

            Console.WriteLine("\nNhap day phan so:");
            ds.Input();

            Console.WriteLine("\nDay phan so vua nhap:");
            ds.Output();

            Console.WriteLine("\nTong cac phan so = " + ds.Tong());
        }
    }
}