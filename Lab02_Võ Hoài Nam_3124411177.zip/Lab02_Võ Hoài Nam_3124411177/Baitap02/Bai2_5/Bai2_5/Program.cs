﻿using System;

namespace Baitap02
{
    class DonThuc
    {
        private double a;
        private int n;

        public DonThuc()
        {
            a = 0;
            n = 0;
        }

        public DonThuc(double a, int n)
        {
            this.a = a;
            this.n = n;
        }

        public DonThuc(DonThuc d)
        {
            a = d.a;
            n = d.n;
        }

        public double GiaTri(double x)
        {
            return a * Math.Pow(x, n);
        }

        public override string ToString()
        {
            if (n == 0)
                return a.ToString();

            if (n == 1)
                return a + "x";

            return a + "x^" + n;
        }
    }

    class DaThuc
    {
        private DonThuc[] ds;

        public DaThuc()
        {
            ds = new DonThuc[0];
        }

        public DaThuc(int n)
        {
            ds = new DonThuc[n + 1];

            for (int i = 0; i <= n; i++)
            {
                ds[i] = new DonThuc(0, i);
            }
        }

        public DaThuc(DaThuc p)
        {
            ds = new DonThuc[p.ds.Length];

            for (int i = 0; i < ds.Length; i++)
            {
                ds[i] = new DonThuc(p.ds[i]);
            }
        }

        public DonThuc this[int i]
        {
            get
            {
                return ds[i];
            }
            set
            {
                ds[i] = value;
            }
        }

        public void Input()
        {
            for (int i = 0; i < ds.Length; i++)
            {
                Console.Write("Nhap he so a" + i + ": ");
                double a = double.Parse(Console.ReadLine());

                ds[i] = new DonThuc(a, i);
            }
        }

        public void Output()
        {
            bool daCo = false;

            for (int i = 0; i < ds.Length; i++)
            {
                if (ds[i].GiaTri(1) == 0)
                    continue;

                if (daCo && ds[i].GiaTri(1) > 0)
                    Console.Write(" + ");

                Console.Write(ds[i]);

                daCo = true;
            }

            if (!daCo)
                Console.Write("0");

            Console.WriteLine();
        }

        public double GiaTri(double x)
        {
            double tong = 0;

            for (int i = 0; i < ds.Length; i++)
            {
                tong += ds[i].GiaTri(x);
            }

            return tong;
        }
    }

    class Bai25
    {
        static void Main()
        {
            Console.Write("Nhap bac cua da thuc n: ");
            int n = int.Parse(Console.ReadLine());

            DaThuc p = new DaThuc(n);

            Console.WriteLine("\nNhap cac he so:");
            p.Input();

            Console.WriteLine("\nDa thuc P(x):");
            p.Output();

            Console.Write("\nNhap gia tri x: ");
            double x = double.Parse(Console.ReadLine());

            Console.WriteLine("Gia tri P(" + x + ") = " + p.GiaTri(x));
        }
    }
}