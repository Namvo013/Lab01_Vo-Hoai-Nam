﻿using System;

namespace Baitap02
{
    class ThiSinh36
    {
        protected string sbd;
        protected string hoTen;
        protected double bai1;
        protected double bai2;
        protected double bai3;

        public ThiSinh36()
        {
            sbd = "";
            hoTen = "";
            bai1 = 0;
            bai2 = 0;
            bai3 = 0;
        }

        public virtual void Nhap()
        {
            do
            {
                Console.Write("Nhap so bao danh: ");
                sbd = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(sbd))
                    Console.WriteLine("So bao danh khong duoc de trong!");

            } while (string.IsNullOrWhiteSpace(sbd));

            while (true)
            {
                Console.Write("Nhap ho ten: ");
                hoTen = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(hoTen))
                {
                    Console.WriteLine("Ho ten khong duoc de trong!");
                    continue;
                }

                bool hopLe = true;

                foreach (char c in hoTen)
                {
                    if (char.IsDigit(c))
                    {
                        hopLe = false;
                        break;
                    }
                }

                if (hopLe)
                    break;

                Console.WriteLine("Ho ten khong duoc chua so!");
            }

            bai1 = NhapDiem("Nhap diem bai 1: ");
            bai2 = NhapDiem("Nhap diem bai 2: ");
            bai3 = NhapDiem("Nhap diem bai 3: ");
        }

        protected double NhapDiem(string thongBao)
        {
            double diem;

            while (true)
            {
                Console.Write(thongBao);

                if (double.TryParse(Console.ReadLine(), out diem) &&
                    diem >= 0 && diem <= 10)
                    return diem;

                Console.WriteLine("Diem phai tu 0 den 10!");
            }
        }

        public virtual double TinhTongDiem()
        {
            return bai1 + bai2 + bai3;
        }

        public virtual void Xuat()
        {
            Console.WriteLine("So bao danh: " + sbd);
            Console.WriteLine("Ho ten: " + hoTen);
            Console.WriteLine("Bai 1: " + bai1);
            Console.WriteLine("Bai 2: " + bai2);
            Console.WriteLine("Bai 3: " + bai3);
            Console.WriteLine("Tong diem: " + TinhTongDiem());
        }
    }

    class ThiSinhChuyen36 : ThiSinh36
    {
        private double tiengAnh;

        public override void Nhap()
        {
            base.Nhap();

            tiengAnh = NhapDiem("Nhap diem tieng Anh: ");
        }

        public override double TinhTongDiem()
        {
            double diem = bai1 + bai2 + bai3;

            if (tiengAnh >= 7 && tiengAnh <= 8)
                diem += 1;
            else if (tiengAnh >= 9 && tiengAnh <= 10)
                diem += 2;

            return diem;
        }

        public override void Xuat()
        {
            Console.WriteLine("Doi tuong: Chuyen");
            base.Xuat();
            Console.WriteLine("Tieng Anh: " + tiengAnh);
        }
    }

    class ThiSinhSieuCup36 : ThiSinh36
    {
        private double csdl;

        public override void Nhap()
        {
            base.Nhap();

            csdl = NhapDiem("Nhap diem CSDL: ");
        }

        public override double TinhTongDiem()
        {
            return bai1 + bai2 + bai3 + csdl;
        }

        public override void Xuat()
        {
            Console.WriteLine("Doi tuong: Sieu cup");
            base.Xuat();
            Console.WriteLine("CSDL: " + csdl);
        }
    }

    class Bai36
    {
        static void Main()
        {
            int n;

            while (true)
            {
                Console.Write("Nhap so luong thi sinh: ");

                if (int.TryParse(Console.ReadLine(), out n) && n > 0)
                    break;

                Console.WriteLine("So luong thi sinh phai la so nguyen duong!");
            }

            ThiSinh36[] danhSach = new ThiSinh36[n];

            for (int i = 0; i < n; i++)
            {
                int loai;

                Console.WriteLine("\nTHI SINH THU " + (i + 1));
                Console.WriteLine("1. Thi sinh Chuyen");
                Console.WriteLine("2. Thi sinh Sieu cup");

                while (true)
                {
                    Console.Write("Chon doi tuong: ");

                    if (int.TryParse(Console.ReadLine(), out loai) &&
                        (loai == 1 || loai == 2))
                        break;

                    Console.WriteLine("Vui long chon 1 hoac 2!");
                }

                if (loai == 1)
                    danhSach[i] = new ThiSinhChuyen36();
                else
                    danhSach[i] = new ThiSinhSieuCup36();

                danhSach[i].Nhap();
            }

            Console.WriteLine("\nKET QUA CUOC THI");

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nTHI SINH THU " + (i + 1));
                danhSach[i].Xuat();
            }
        }
    }
}