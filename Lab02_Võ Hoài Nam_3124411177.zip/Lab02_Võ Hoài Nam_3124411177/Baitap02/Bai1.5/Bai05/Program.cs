﻿using System;

namespace Baitap02
{
    class DonThuc
    {
        private double a;
        private int n;

        public DonThuc()
        {
            a = 0;
            n = 0;
        }

        public DonThuc(double a, int n)
        {
            if (n < 0)
                throw new ArgumentException("So mu n phai khong am");

            this.a = a;
            this.n = n;
        }

        public double GiaTri(double x)
        {
            return a * Math.Pow(x, n);
        }

        public DonThuc DaoHam()
        {
            if (n == 0)
                return new DonThuc(0, 0);

            return new DonThuc(a * n, n - 1);
        }

        public override string ToString()
        {
            if (n == 0)
                return a.ToString();

            if (n == 1)
                return a + "x";

            return a + "x^" + n;
        }
    }

    class Bai05
    {
        static void Main()
        {
            Console.Write("Nhap he so a: ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("Nhap so mu n: ");
            int n = int.Parse(Console.ReadLine());

            DonThuc p = new DonThuc(a, n);

            Console.Write("Nhap gia tri x: ");
            double x = double.Parse(Console.ReadLine());

            Console.WriteLine("\nDon thuc P(x) = " + p);
            Console.WriteLine("Gia tri P(" + x + ") = " + p.GiaTri(x));

            DonThuc q = p.DaoHam();

            Console.WriteLine("Dao ham P'(x) = " + q);
            Console.WriteLine("Gia tri P'(" + x + ") = " + q.GiaTri(x));
        }
    }
}