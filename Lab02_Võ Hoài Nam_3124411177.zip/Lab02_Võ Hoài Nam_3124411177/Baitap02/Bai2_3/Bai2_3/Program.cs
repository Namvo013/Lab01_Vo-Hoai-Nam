﻿using System;

namespace Baitap02
{
    class DaySo
    {
        private int[] a;

        public DaySo()
        {
            a = new int[0];
        }

        public DaySo(int n)
        {
            a = new int[n];
        }

        public DaySo(DaySo d)
        {
            a = new int[d.a.Length];

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = d.a[i];
            }
        }

        public int this[int i]
        {
            get
            {
                return a[i];
            }
            set
            {
                a[i] = value;
            }
        }

        public void Input()
        {
            for (int i = 0; i < a.Length; i++)
            {
                while (true)
                {
                    Console.Write("Nhap phan tu thu " + i + ": ");

                    if (int.TryParse(Console.ReadLine(), out a[i]))
                        break;

                    Console.WriteLine("Vui long nhap so nguyen!");
                }
            }
        }

        public void Output()
        {
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + " ");
            }

            Console.WriteLine();
        }

        public DaySo TimSoChan()
        {
            int dem = 0;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 == 0)
                {
                    dem++;
                }
            }

            DaySo ketQua = new DaySo(dem);

            int j = 0;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 == 0)
                {
                    ketQua[j] = a[i];
                    j++;
                }
            }

            return ketQua;
        }

        public int Length
        {
            get
            {
                return a.Length;
            }
        }
    }

    class Bai23
    {
        static void Main()
        {
            Console.Write("Nhap so luong phan tu n: ");
            int n = int.Parse(Console.ReadLine());

            DaySo d = new DaySo(n);

            Console.WriteLine("\nNhap day so:");
            d.Input();

            Console.WriteLine("\nDay so vua nhap:");
            d.Output();

            DaySo soChan = d.TimSoChan();

            Console.WriteLine("\nCac so chan:");
            soChan.Output();
        }
    }
}