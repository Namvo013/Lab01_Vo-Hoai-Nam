﻿using System;

namespace Baitap02
{
    class SinhVien31 : IComparable<SinhVien31>
    {
        private string maSV;
        private string hoTen;
        private double diemTB;

        public SinhVien31()
        {
            maSV = "";
            hoTen = "";
            diemTB = 0;
        }

        public SinhVien31(string maSV, string hoTen, double diemTB)
        {
            this.maSV = maSV;
            this.hoTen = hoTen;
            this.diemTB = diemTB;
        }

        public void Nhap()
        {
            do
            {
                Console.Write("Nhap ma sinh vien: ");
                maSV = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(maSV))
                    Console.WriteLine("Ma sinh vien khong duoc de trong!");

            } while (string.IsNullOrWhiteSpace(maSV));

            while (true)
            {
                Console.Write("Nhap ho ten: ");
                hoTen = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(hoTen))
                {
                    Console.WriteLine("Ho ten khong duoc de trong!");
                    continue;
                }

                bool hopLe = true;

                foreach (char c in hoTen)
                {
                    if (char.IsDigit(c))
                    {
                        hopLe = false;
                        break;
                    }
                }

                if (hopLe)
                    break;

                Console.WriteLine("Ho ten khong duoc chua so!");
            }

            while (true)
            {
                Console.Write("Nhap diem trung binh: ");

                if (double.TryParse(Console.ReadLine(), out diemTB) && diemTB >= 0 && diemTB <= 10)
                    break;

                Console.WriteLine("Diem phai tu 0 den 10!");
            }
        }

        public void Xuat()
        {
            Console.WriteLine("Ma SV: " + maSV);
            Console.WriteLine("Ho ten: " + hoTen);
            Console.WriteLine("Diem TB: " + diemTB);
        }

        public int CompareTo(SinhVien31 other)
        {
            return diemTB.CompareTo(other.diemTB);
        }
    }

    class Bai31
    {
        static void Main()
        {
            int n;

            Console.Write("Nhap so luong sinh vien: ");

            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.WriteLine("So luong phai la so nguyen duong!");
                Console.Write("Nhap lai: ");
            }

            SinhVien31[] danhSach = new SinhVien31[n];

            Console.WriteLine("\nNHAP DANH SACH SINH VIEN");

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nSinh vien thu " + (i + 1));
                danhSach[i] = new SinhVien31();
                danhSach[i].Nhap();
            }

            Console.WriteLine("\nDANH SACH TRUOC KHI SAP XEP");

            for (int i = 0; i < n; i++)
            {
                danhSach[i].Xuat();
                Console.WriteLine();
            }

            Array.Sort(danhSach);

            Console.WriteLine("\nDANH SACH SAU KHI SAP XEP THEO DIEM TB TANG DAN");

            for (int i = 0; i < n; i++)
            {
                danhSach[i].Xuat();
                Console.WriteLine();
            }
        }
    }
}