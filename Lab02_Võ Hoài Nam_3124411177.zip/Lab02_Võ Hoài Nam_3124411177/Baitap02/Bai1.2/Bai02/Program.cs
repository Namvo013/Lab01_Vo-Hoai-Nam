﻿using System;

namespace Baitap02
{
    class Point
    {
        // Field
        private double x;
        private double y;

        // Property
        public double X
        {
            get { return x; }
            set { x = value; }
        }

        public double Y
        {
            get { return y; }
            set { y = value; }
        }

        // Default Constructor
        public Point()
        {
            x = 0;
            y = 0;
        }

        // Constructor có tham số
        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        // Method Input
        public void Input()
        {
            Console.Write("Nhap x: ");
            x = double.Parse(Console.ReadLine());

            Console.Write("Nhap y: ");
            y = double.Parse(Console.ReadLine());
        }

        // Method Output
        public void Output()
        {
            Console.WriteLine("(" + x + ", " + y + ")");
        }

        // Override ToString()
        public override string ToString()
        {
            return "(" + x + ", " + y + ")";
        }

        // Phép cộng 2 Point
        public static Point operator +(Point A, Point B)
        {
            return new Point(A.x + B.x, A.y + B.y);
        }

        // Phép trừ 2 Point
        public static Point operator -(Point A, Point B)
        {
            return new Point(A.x - B.x, A.y - B.y);
        }

        // Phép lấy âm
        public static Point operator -(Point A)
        {
            return new Point(-A.x, -A.y);
        }

        // (a) Khoảng cách - phương thức thành viên
        public double Distance(Point B)
        {
            double dx = x - B.x;
            double dy = y - B.y;

            return Math.Sqrt(dx * dx + dy * dy);
        }

        // (a) Khoảng cách - phương thức tĩnh
        public static double Distance(Point A, Point B)
        {
            double dx = A.x - B.x;
            double dy = A.y - B.y;

            return Math.Sqrt(dx * dx + dy * dy);
        }

        // (b) Trung điểm - phương thức thành viên
        public Point MidPoint(Point B)
        {
            return new Point(
                (x + B.x) / 2,
                (y + B.y) / 2
            );
        }

        // (b) Trung điểm - phương thức tĩnh
        public static Point MidPoint(Point A, Point B)
        {
            return new Point(
                (A.x + B.x) / 2,
                (A.y + B.y) / 2
            );
        }
    }

    class Bai2
    {
        static void Main()
        {
            // Nhập điểm A
            Console.WriteLine("Nhap diem A:");
            Point A = new Point();
            A.Input();

            // Nhập điểm B
            Console.WriteLine("\nNhap diem B:");
            Point B = new Point();
            B.Input();

            // Xuất A, B
            Console.WriteLine("\nDiem A: " + A);
            Console.WriteLine("Diem B: " + B);

            // Khoang cach - phuong thuc thanh vien
            double d1 = A.Distance(B);
            Console.WriteLine("\nKhoang cach AB (thanh vien): " + d1);

            // Khoang cach - phuong thuc tinh
            double d2 = Point.Distance(A, B);
            Console.WriteLine("Khoang cach AB (tinh): " + d2);

            // Trung diem - phuong thuc thanh vien
            Point I1 = A.MidPoint(B);
            Console.WriteLine("\nTrung diem I (thanh vien): " + I1);

            // Trung diem - phuong thuc tinh
            Point I2 = Point.MidPoint(A, B);
            Console.WriteLine("Trung diem I (tinh): " + I2);

            // Phép cộng
            Point C = A + B;
            Console.WriteLine("\nA + B = " + C);

            // Phép trừ
            Point D = A - B;
            Console.WriteLine("A - B = " + D);

            // Phép lấy âm
            Point E = -A;
            Console.WriteLine("-A = " + E);
        }
    }
}