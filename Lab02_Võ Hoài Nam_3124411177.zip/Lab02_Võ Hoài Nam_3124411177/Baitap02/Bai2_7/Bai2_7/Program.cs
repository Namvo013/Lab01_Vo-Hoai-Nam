﻿using System;

namespace Baitap02
{
    class NhanVien27
    {
        private string hoTen;
        private double mucLuong;
        private int soNgayVang;

        public NhanVien27()
        {
            hoTen = "";
            mucLuong = 0;
            soNgayVang = 0;
        }

        public void Nhap()
        {
            Console.Write("Nhap ho ten: ");
            hoTen = Console.ReadLine();

            while (true)
            {
                Console.Write("Nhap muc luong: ");

                if (double.TryParse(Console.ReadLine(), out mucLuong) && mucLuong >= 0)
                    break;

                Console.WriteLine("Muc luong khong hop le, vui long nhap lai!");
            }

            while (true)
            {
                Console.Write("Nhap so ngay vang: ");

                if (int.TryParse(Console.ReadLine(), out soNgayVang) && soNgayVang >= 0)
                    break;

                Console.WriteLine("So ngay vang khong hop le, vui long nhap lai!");
            }
        }

        public double TinhLuong()
        {
            return mucLuong - soNgayVang * 100000;
        }

        public void Xuat()
        {
            Console.WriteLine("Ho ten: " + hoTen);
            Console.WriteLine("Muc luong: " + mucLuong.ToString("N0"));
            Console.WriteLine("So ngay vang: " + soNgayVang);
            Console.WriteLine("Luong thuc nhan: " + TinhLuong().ToString("N0") + " VNĐ");
        }
    }

    class PhongBan27
    {
        private NhanVien27[] danhSach;

        public PhongBan27(int n)
        {
            danhSach = new NhanVien27[n];

            for (int i = 0; i < n; i++)
            {
                danhSach[i] = new NhanVien27();
            }
        }

        public void Nhap()
        {
            for (int i = 0; i < danhSach.Length; i++)
            {
                Console.WriteLine("\nNhan vien thu " + (i + 1));
                danhSach[i].Nhap();
            }
        }

        public void Xuat()
        {
            for (int i = 0; i < danhSach.Length; i++)
            {
                Console.WriteLine("\nNhan vien thu " + (i + 1));
                danhSach[i].Xuat();
            }
        }

        public double TongLuong()
        {
            double tong = 0;

            for (int i = 0; i < danhSach.Length; i++)
            {
                tong += danhSach[i].TinhLuong();
            }

            return tong;
        }
    }

    class Bai27
    {
        static void Main()
        {
            int n;

            Console.Write("Nhap so luong nhan vien: ");

            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.WriteLine("So luong nhan vien phai la so nguyen duong!");
                Console.Write("Nhap lai: ");
            }

            PhongBan27 phongBan = new PhongBan27(n);

            Console.WriteLine("\nNHAP THONG TIN NHAN VIEN");
            phongBan.Nhap();

            Console.WriteLine("\nTHONG TIN NHAN VIEN");
            phongBan.Xuat();

            Console.WriteLine("\nTong luong cua phong ban: "
                + phongBan.TongLuong().ToString("N0") + " VNĐ");
        }
    }
}