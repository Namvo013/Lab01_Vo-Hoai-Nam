﻿using System;

namespace Baitap02
{
    interface ISoSanh<T>
    {
        int SoSanh(T other);
    }

    class SinhVien32 : ISoSanh<SinhVien32>
    {
        private string maSV;
        private string hoTen;
        private double diemTB;

        public SinhVien32()
        {
            maSV = "";
            hoTen = "";
            diemTB = 0;
        }

        public void Nhap()
        {
            do
            {
                Console.Write("Nhap ma sinh vien: ");
                maSV = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(maSV))
                    Console.WriteLine("Ma sinh vien khong duoc de trong!");

            } while (string.IsNullOrWhiteSpace(maSV));

            while (true)
            {
                Console.Write("Nhap ho ten: ");
                hoTen = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(hoTen))
                {
                    Console.WriteLine("Ho ten khong duoc de trong!");
                    continue;
                }

                bool hopLe = true;

                foreach (char c in hoTen)
                {
                    if (char.IsDigit(c))
                    {
                        hopLe = false;
                        break;
                    }
                }

                if (hopLe)
                    break;

                Console.WriteLine("Ho ten khong duoc chua so!");
            }

            while (true)
            {
                Console.Write("Nhap diem trung binh: ");

                if (double.TryParse(Console.ReadLine(), out diemTB) &&
                    diemTB >= 0 && diemTB <= 10)
                    break;

                Console.WriteLine("Diem phai tu 0 den 10!");
            }
        }

        public void Xuat()
        {
            Console.WriteLine("Ma SV: " + maSV);
            Console.WriteLine("Ho ten: " + hoTen);
            Console.WriteLine("Diem TB: " + diemTB);
        }

        public int SoSanh(SinhVien32 other)
        {
            return diemTB.CompareTo(other.diemTB);
        }
    }

    class SapXep32
    {
        public static void Sort<T>(T[] a) where T : ISoSanh<T>
        {
            for (int i = 0; i < a.Length - 1; i++)
            {
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (a[i].SoSanh(a[j]) > 0)
                    {
                        T temp = a[i];
                        a[i] = a[j];
                        a[j] = temp;
                    }
                }
            }
        }
    }

    class Bai32
    {
        static void Main()
        {
            int n;

            Console.Write("Nhap so luong sinh vien: ");

            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.WriteLine("So luong phai la so nguyen duong!");
                Console.Write("Nhap lai: ");
            }

            SinhVien32[] danhSach = new SinhVien32[n];

            Console.WriteLine("\nNHAP DANH SACH SINH VIEN");

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nSinh vien thu " + (i + 1));
                danhSach[i] = new SinhVien32();
                danhSach[i].Nhap();
            }

            Console.WriteLine("\nDANH SACH TRUOC KHI SAP XEP");

            for (int i = 0; i < n; i++)
            {
                danhSach[i].Xuat();
                Console.WriteLine();
            }

            SapXep32.Sort(danhSach);

            Console.WriteLine("\nDANH SACH SAU KHI SAP XEP");

            for (int i = 0; i < n; i++)
            {
                danhSach[i].Xuat();
                Console.WriteLine();
            }
        }
    }
}