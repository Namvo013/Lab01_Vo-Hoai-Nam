﻿using System;

namespace Baitap02
{
    class PhanSo
    {
        private double tu;
        private double mau;

        public PhanSo()
        {
            tu = 0;
            mau = 1;
        }

        public PhanSo(double tu)
        {
            this.tu = tu;
            mau = 1;
        }

        public PhanSo(double tu, double mau)
        {
            if (mau == 0)
                throw new ArgumentException("Mau so phai khac 0");

            this.tu = tu;
            this.mau = mau;
        }

        public PhanSo(PhanSo p)
        {
            tu = p.tu;
            mau = p.mau;
        }

        public override string ToString()
        {
            return tu + "/" + mau;
        }

        public static PhanSo operator +(PhanSo p)
        {
            return new PhanSo(p.tu, p.mau);
        }

        public static PhanSo operator -(PhanSo p)
        {
            return new PhanSo(-p.tu, p.mau);
        }

        public static PhanSo operator +(PhanSo p1, PhanSo p2)
        {
            return new PhanSo(
                p1.tu * p2.mau + p2.tu * p1.mau,
                p1.mau * p2.mau
            );
        }

        public static PhanSo operator -(PhanSo p1, PhanSo p2)
        {
            return new PhanSo(
                p1.tu * p2.mau - p2.tu * p1.mau,
                p1.mau * p2.mau
            );
        }

        public static PhanSo operator *(PhanSo p1, PhanSo p2)
        {
            return new PhanSo(
                p1.tu * p2.tu,
                p1.mau * p2.mau
            );
        }

        public static PhanSo operator /(PhanSo p1, PhanSo p2)
        {
            if (p2.tu == 0)
                throw new DivideByZeroException("Khong the chia cho 0");

            return new PhanSo(
                p1.tu * p2.mau,
                p1.mau * p2.tu
            );
        }

        public static bool operator >(PhanSo p1, PhanSo p2)
        {
            return p1.tu * p2.mau > p2.tu * p1.mau;
        }

        public static bool operator <(PhanSo p1, PhanSo p2)
        {
            return p1.tu * p2.mau < p2.tu * p1.mau;
        }

        public static bool operator >=(PhanSo p1, PhanSo p2)
        {
            return p1.tu * p2.mau >= p2.tu * p1.mau;
        }

        public static bool operator <=(PhanSo p1, PhanSo p2)
        {
            return p1.tu * p2.mau <= p2.tu * p1.mau;
        }

        public static bool operator ==(PhanSo p1, PhanSo p2)
        {
            if (ReferenceEquals(p1, p2))
                return true;

            if (p1 is null || p2 is null)
                return false;

            return p1.tu * p2.mau == p2.tu * p1.mau;
        }

        public static bool operator !=(PhanSo p1, PhanSo p2)
        {
            return !(p1 == p2);
        }

        public override bool Equals(object obj)
        {
            if (obj is PhanSo p)
                return this == p;

            return false;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(tu, mau);
        }
    }

    class Bai04
    {
        static void Main()
        {
            Console.Write("Nhap tu so p1: ");
            double tu1 = double.Parse(Console.ReadLine());

            Console.Write("Nhap mau so p1: ");
            double mau1 = double.Parse(Console.ReadLine());

            Console.Write("Nhap tu so p2: ");
            double tu2 = double.Parse(Console.ReadLine());

            Console.Write("Nhap mau so p2: ");
            double mau2 = double.Parse(Console.ReadLine());

            PhanSo p1 = new PhanSo(tu1, mau1);
            PhanSo p2 = new PhanSo(tu2, mau2);

            Console.WriteLine("\nPhan so p1: " + p1);
            Console.WriteLine("Phan so p2: " + p2);

            Console.WriteLine("\n+p1 = " + (+p1));
            Console.WriteLine("-p1 = " + (-p1));

            Console.WriteLine("\np1 + p2 = " + (p1 + p2));
            Console.WriteLine("p1 - p2 = " + (p1 - p2));
            Console.WriteLine("p1 * p2 = " + (p1 * p2));
            Console.WriteLine("p1 / p2 = " + (p1 / p2));

            Console.WriteLine("\np1 > p2: " + (p1 > p2));
            Console.WriteLine("p1 < p2: " + (p1 < p2));
            Console.WriteLine("p1 >= p2: " + (p1 >= p2));
            Console.WriteLine("p1 <= p2: " + (p1 <= p2));
            Console.WriteLine("p1 == p2: " + (p1 == p2));
            Console.WriteLine("p1 != p2: " + (p1 != p2));

            PhanSo p3 = new PhanSo(p1);
            Console.WriteLine("\nPhan so sao chep p3: " + p3);
        }
    }
}