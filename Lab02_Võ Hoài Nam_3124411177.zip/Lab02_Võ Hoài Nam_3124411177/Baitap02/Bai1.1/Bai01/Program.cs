﻿using System;

namespace Baitap02
{
    class Bai01
    {
        static void Main()
        {
            Console.Write("Nhap ho ten sinh vien: ");
            string hoTen = Console.ReadLine();

            Console.Write("Nhap nam sinh: ");
            int namSinh = int.Parse(Console.ReadLine());

            int tuoi = DateTime.Now.Year - namSinh;

            Console.WriteLine("Ho ten: " + hoTen);
            Console.WriteLine("Tuoi: " + tuoi);
        }
    }
}