﻿using System;

namespace Baitap02
{
    class MangHaiChieu
    {
        private int[,] a;

        public MangHaiChieu()
        {
            a = new int[0, 0];
        }

        public MangHaiChieu(int n, int m)
        {
            a = new int[n, m];
        }

        public MangHaiChieu(MangHaiChieu b)
        {
            int n = b.a.GetLength(0);
            int m = b.a.GetLength(1);

            a = new int[n, m];

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    a[i, j] = b.a[i, j];
                }
            }
        }

        public int this[int i, int j]
        {
            get
            {
                return a[i, j];
            }
            set
            {
                a[i, j] = value;
            }
        }

        public void Input()
        {
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    while (true)
                    {
                        Console.Write("Nhap a[" + i + "," + j + "]: ");

                        if (int.TryParse(Console.ReadLine(), out a[i, j]))
                            break;

                        Console.WriteLine("Vui long nhap so nguyen!");
                    }
                }
            }
        }

        public void Output()
        {
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    Console.Write(a[i, j] + "\t");
                }

                Console.WriteLine();
            }
        }

        private bool LaSoNguyenTo(int n)
        {
            if (n < 2)
                return false;

            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                    return false;
            }

            return true;
        }

        public MangHaiChieu TimSoNguyenTo()
        {
            int dem = 0;

            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    if (LaSoNguyenTo(a[i, j]))
                    {
                        dem++;
                    }
                }
            }

            MangHaiChieu ketQua = new MangHaiChieu(1, dem);

            int k = 0;

            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    if (LaSoNguyenTo(a[i, j]))
                    {
                        ketQua[0, k] = a[i, j];
                        k++;
                    }
                }
            }

            return ketQua;
        }

        public int Rows
        {
            get
            {
                return a.GetLength(0);
            }
        }

        public int Columns
        {
            get
            {
                return a.GetLength(1);
            }
        }
    }

    class Bai24
    {
        static void Main()
        {
            Console.Write("Nhap so dong n: ");
            int n = int.Parse(Console.ReadLine());

            Console.Write("Nhap so cot m: ");
            int m = int.Parse(Console.ReadLine());

            MangHaiChieu a = new MangHaiChieu(n, m);

            Console.WriteLine("\nNhap mang:");
            a.Input();

            Console.WriteLine("\nMang vua nhap:");
            a.Output();

            MangHaiChieu soNguyenTo = a.TimSoNguyenTo();

            Console.WriteLine("\nCac so nguyen to trong mang:");

            soNguyenTo.Output();
        }
    }
}