﻿using System;
using System.Collections;

namespace Baitap02
{
    class Point
    {
        private double x;
        private double y;

        public Point()
        {
            x = 0;
            y = 0;
        }

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public override string ToString()
        {
            return "(" + x + ", " + y + ")";
        }
    }

    class ArrayPoint
    {
        private ArrayList dsPoint;

        public ArrayPoint()
        {
            dsPoint = new ArrayList();
        }

        public Point this[int i]
        {
            get
            {
                return (Point)dsPoint[i];
            }
            set
            {
                dsPoint[i] = value;
            }
        }

        public void Add(Point p)
        {
            dsPoint.Add(p);
        }

        public int Count
        {
            get
            {
                return dsPoint.Count;
            }
        }
    }

    class Bai21
    {
        static void Main()
        {
            ArrayPoint arr = new ArrayPoint();

            Console.Write("Nhap so luong Point: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nNhap Point thu " + i);

                Console.Write("Nhap x: ");
                double x = double.Parse(Console.ReadLine());

                Console.Write("Nhap y: ");
                double y = double.Parse(Console.ReadLine());

                arr.Add(new Point(x, y));
            }

            Console.WriteLine("\nDanh sach Point:");

            for (int i = 0; i < arr.Count; i++)
            {
                Console.WriteLine("Point thu " + i + ": " + arr[i]);
            }

            Console.Write("\nNhap vi tri Point can xem: ");
            int vt = int.Parse(Console.ReadLine());

            Console.WriteLine("Point thu " + vt + ": " + arr[vt]);
        }
    }
}