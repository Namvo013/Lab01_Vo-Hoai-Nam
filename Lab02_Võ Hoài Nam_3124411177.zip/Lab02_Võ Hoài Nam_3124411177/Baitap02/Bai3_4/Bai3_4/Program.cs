﻿using System;

namespace Baitap02
{
    delegate void ChooseHandler(int choice);

    class ConsoleMenu
    {
        public event ChooseHandler Choose;

        public void Run()
        {
            int chon;

            do
            {
                Console.Clear();

                Console.WriteLine("MENU");
                Console.WriteLine("1. Nhap phuong trinh bac 2");
                Console.WriteLine("2. Giai phuong trinh bac 2");
                Console.WriteLine("0. Thoat chuong trinh");
                Console.Write("Thuc hien: ");

                while (!int.TryParse(Console.ReadLine(), out chon))
                {
                    Console.Write("Vui long nhap so: ");
                }

                if (chon != 0)
                {
                    Choose?.Invoke(chon);

                    Console.WriteLine("\nNhan Enter de tiep tuc...");
                    Console.ReadLine();
                }

            } while (chon != 0);
        }
    }

    class PTBac2Console : ConsoleMenu
    {
        private double a;
        private double b;
        private double c;

        public PTBac2Console()
        {
            Choose += XuLyChucNang;
        }

        private void XuLyChucNang(int choice)
        {
            switch (choice)
            {
                case 1:
                    NhapPhuongTrinh();
                    break;

                case 2:
                    GiaiPhuongTrinh();
                    break;

                default:
                    Console.WriteLine("Chuc nang khong ton tai!");
                    break;
            }
        }

        private void NhapPhuongTrinh()
        {
            Console.WriteLine("\nNHAP PHUONG TRINH BAC 2");

            while (true)
            {
                Console.Write("Nhap a: ");

                if (double.TryParse(Console.ReadLine(), out a) && a != 0)
                    break;

                Console.WriteLine("a phai la so khac 0!");
            }

            while (true)
            {
                Console.Write("Nhap b: ");

                if (double.TryParse(Console.ReadLine(), out b))
                    break;

                Console.WriteLine("b phai la so!");
            }

            while (true)
            {
                Console.Write("Nhap c: ");

                if (double.TryParse(Console.ReadLine(), out c))
                    break;

                Console.WriteLine("c phai la so!");
            }

            Console.WriteLine("Phuong trinh: " + a + "x^2 + " + b + "x + " + c + " = 0");
        }

        private void GiaiPhuongTrinh()
        {
            double delta = b * b - 4 * a * c;

            Console.WriteLine("\nGIAI PHUONG TRINH");

            Console.WriteLine("Phuong trinh: " + a + "x^2 + " + b + "x + " + c + " = 0");

            if (delta < 0)
            {
                Console.WriteLine("Phuong trinh vo nghiem.");
            }
            else if (delta == 0)
            {
                double x = -b / (2 * a);
                Console.WriteLine("Phuong trinh co nghiem kep x = " + x);
            }
            else
            {
                double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                double x2 = (-b - Math.Sqrt(delta)) / (2 * a);

                Console.WriteLine("Phuong trinh co 2 nghiem:");
                Console.WriteLine("x1 = " + x1);
                Console.WriteLine("x2 = " + x2);
            }
        }
    }

    class Bai34
    {
        static void Main()
        {
            PTBac2Console app = new PTBac2Console();

            app.Run();
        }
    }
}