﻿using System;
using System.Collections;

namespace Baitap02
{
    class Person
    {
        private string id;
        private string name;
        private int yob;
        private int yod;

        public Person()
        {
            id = "";
            name = "";
            yob = 0;
            yod = 0;
        }

        public Person(Person p)
        {
            id = p.id;
            name = p.name;
            yob = p.yob;
            yod = p.yod;
        }

        public void Input()
        {
            Console.Write("Nhap ID: ");
            id = Console.ReadLine();

            Console.Write("Nhap ho ten: ");
            name = Console.ReadLine();

            Console.Write("Nhap nam sinh: ");
            yob = int.Parse(Console.ReadLine());

            Console.Write("Nhap nam mat: ");
            yod = int.Parse(Console.ReadLine());
        }

        public void Output()
        {
            Console.WriteLine("ID: " + id);
            Console.WriteLine("Ho ten: " + name);
            Console.WriteLine("Nam sinh: " + yob);
            Console.WriteLine("Nam mat: " + yod);
        }

        public bool IsLiving()
        {
            return yod == 0;
        }
    }

    class PersonList
    {
        private ArrayList dsPerson;

        public PersonList()
        {
            dsPerson = new ArrayList();
        }

        public PersonList(PersonList p)
        {
            dsPerson = new ArrayList();

            for (int i = 0; i < p.dsPerson.Count; i++)
            {
                Person person = new Person((Person)p.dsPerson[i]);
                dsPerson.Add(person);
            }
        }

        public void Input()
        {
            Console.Write("Nhap so luong nguoi: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nNhap nguoi thu " + (i + 1));

                Person p = new Person();
                p.Input();

                Add(p);
            }
        }

        public void Output()
        {
            for (int i = 0; i < dsPerson.Count; i++)
            {
                Console.WriteLine("\nNguoi thu " + (i + 1));
                ((Person)dsPerson[i]).Output();
            }
        }

        public void Add(Person x)
        {
            dsPerson.Add(x);
        }

        public PersonList LivingPeople()
        {
            PersonList result = new PersonList();

            for (int i = 0; i < dsPerson.Count; i++)
            {
                Person p = (Person)dsPerson[i];

                if (p.IsLiving())
                {
                    result.Add(new Person(p));
                }
            }

            return result;
        }
    }

    class Bai22
    {
        static void Main()
        {
            PersonList danhSach = new PersonList();

            danhSach.Input();

            Console.WriteLine("\nDanh sach tat ca:");
            danhSach.Output();

            PersonList nguoiConSong = danhSach.LivingPeople();

            Console.WriteLine("\nDanh sach nguoi con song:");
            nguoiConSong.Output();
        }
    }
}