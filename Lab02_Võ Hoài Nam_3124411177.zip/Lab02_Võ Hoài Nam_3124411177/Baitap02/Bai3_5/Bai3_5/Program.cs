﻿using System;

namespace Baitap02
{
    class NhanVien35
    {
        protected string maNV;
        protected string hoTen;

        public NhanVien35()
        {
            maNV = "";
            hoTen = "";
        }

        public virtual void Nhap()
        {
            do
            {
                Console.Write("Nhap ma nhan vien: ");
                maNV = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(maNV))
                    Console.WriteLine("Ma nhan vien khong duoc de trong!");

            } while (string.IsNullOrWhiteSpace(maNV));

            while (true)
            {
                Console.Write("Nhap ho ten: ");
                hoTen = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(hoTen))
                {
                    Console.WriteLine("Ho ten khong duoc de trong!");
                    continue;
                }

                bool hopLe = true;

                foreach (char c in hoTen)
                {
                    if (char.IsDigit(c))
                    {
                        hopLe = false;
                        break;
                    }
                }

                if (hopLe)
                    break;

                Console.WriteLine("Ho ten khong duoc chua so!");
            }
        }

        public virtual double TinhLuong()
        {
            return 0;
        }

        public virtual void Xuat()
        {
            Console.WriteLine("Ma nhan vien: " + maNV);
            Console.WriteLine("Ho ten: " + hoTen);
            Console.WriteLine("Luong: " + TinhLuong().ToString("N0") + " VND");
        }
    }

    class NhanVienKinhDoanh35 : NhanVien35
    {
        private double luongCoBan;
        private int soHopDong;

        public override void Nhap()
        {
            base.Nhap();

            while (true)
            {
                Console.Write("Nhap luong co ban: ");

                if (double.TryParse(Console.ReadLine(), out luongCoBan) && luongCoBan >= 0)
                    break;

                Console.WriteLine("Luong co ban phai la so khong am!");
            }

            while (true)
            {
                Console.Write("Nhap so hop dong: ");

                if (int.TryParse(Console.ReadLine(), out soHopDong) && soHopDong >= 0)
                    break;

                Console.WriteLine("So hop dong phai la so nguyen khong am!");
            }
        }

        public override double TinhLuong()
        {
            return luongCoBan + soHopDong * 500000;
        }

        public override void Xuat()
        {
            Console.WriteLine("Loai nhan vien: Kinh doanh");
            base.Xuat();
        }
    }

    class NhanVienSanXuat35 : NhanVien35
    {
        private int soSanPham;

        public override void Nhap()
        {
            base.Nhap();

            while (true)
            {
                Console.Write("Nhap so luong san pham: ");

                if (int.TryParse(Console.ReadLine(), out soSanPham) && soSanPham >= 0)
                    break;

                Console.WriteLine("So san pham phai la so nguyen khong am!");
            }
        }

        public override double TinhLuong()
        {
            double luong = soSanPham * 1000;

            if (soSanPham > 3000)
                luong += luong * 0.05;

            return luong;
        }

        public override void Xuat()
        {
            Console.WriteLine("Loai nhan vien: San xuat");
            base.Xuat();
        }
    }

    class Bai35
    {
        static void Main()
        {
            int n;

            while (true)
            {
                Console.Write("Nhap so luong nhan vien: ");

                if (int.TryParse(Console.ReadLine(), out n) && n > 0)
                    break;

                Console.WriteLine("So luong nhan vien phai la so nguyen duong!");
            }

            NhanVien35[] danhSach = new NhanVien35[n];

            for (int i = 0; i < n; i++)
            {
                int loai;

                Console.WriteLine("\nNHAN VIEN THU " + (i + 1));
                Console.WriteLine("1. Nhan vien kinh doanh");
                Console.WriteLine("2. Nhan vien san xuat");

                while (true)
                {
                    Console.Write("Chon loai nhan vien: ");

                    if (int.TryParse(Console.ReadLine(), out loai) && (loai == 1 || loai == 2))
                        break;

                    Console.WriteLine("Vui long chon 1 hoac 2!");
                }

                if (loai == 1)
                    danhSach[i] = new NhanVienKinhDoanh35();
                else
                    danhSach[i] = new NhanVienSanXuat35();

                danhSach[i].Nhap();
            }

            Console.WriteLine("\nDANH SACH NHAN VIEN");

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\nNhan vien thu " + (i + 1));
                danhSach[i].Xuat();
            }
        }
    }
}