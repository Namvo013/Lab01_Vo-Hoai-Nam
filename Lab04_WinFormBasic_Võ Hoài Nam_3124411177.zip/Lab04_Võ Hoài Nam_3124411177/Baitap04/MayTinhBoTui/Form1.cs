using System;
using System.Drawing;
using System.Windows.Forms;

namespace MayTinhBoTui
{
    public partial class Form1 : Form
    {
        TextBox txtHienThi;

        double soThuNhat = 0;
        string phepTinh = "";
        bool batDauNhapSoMoi = true;

        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
        }

        private void TaoGiaoDien()
        {
            Text = "Máy Tính Bỏ Túi";
            StartPosition = FormStartPosition.CenterScreen;
            // Tăng kích thước Form để chứa các nút lớn hơn (Rộng 350, Cao 410)
            ClientSize = new Size(350, 410);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = true;
            BackColor = Color.WhiteSmoke;

            // Cho phép Form nhận diện phím bấm từ bàn phím
            this.KeyPreview = true;
            this.KeyPress += Form1_KeyPress;

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "Máy Tính Bỏ Túi";
            lblTieuDe.Font = new Font("Times New Roman", 21, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.Red;
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            lblTieuDe.Location = new Point(0, 10);
            lblTieuDe.Size = new Size(350, 48);
            Controls.Add(lblTieuDe);

            txtHienThi = new TextBox();
            // Điều chỉnh vị trí và kéo dài TextBox
            txtHienThi.Location = new Point(20, 65);
            txtHienThi.Size = new Size(310, 45);
            txtHienThi.Font = new Font("Arial", 22, FontStyle.Bold); // Phóng to chữ hiển thị
            txtHienThi.TextAlign = HorizontalAlignment.Right;
            txtHienThi.ReadOnly = true;
            txtHienThi.BackColor = Color.White;
            txtHienThi.Text = "0";
            Controls.Add(txtHienThi);

            string[,] nut =
            {
                { "1", "2", "3", "4" },
                { "5", "6", "7", "8" },
                { "9", "0", "=", "C" },
                { "+", "-", "*", "/" }
            };

            // THAY ĐỔI KÍCH THƯỚC NÚT Ở ĐÂY
            int x = 20;       // Tọa độ bắt đầu lùi sang trái một chút
            int y = 120;      // Tọa độ Y bắt đầu
            int rong = 70;    // Tăng chiều rộng nút (cũ: 52)
            int cao = 60;     // Tăng chiều cao nút (cũ: 37)
            int khoangX = 10; // Khoảng cách ngang giữa các nút
            int khoangY = 10; // Khoảng cách dọc giữa các nút

            for (int dong = 0; dong < 4; dong++)
            {
                for (int cot = 0; cot < 4; cot++)
                {
                    Button btn = new Button();

                    btn.Text = nut[dong, cot];
                    btn.Font = new Font("Arial", 16, FontStyle.Bold); // Phóng to chữ trên nút
                    btn.Size = new Size(rong, cao);
                    btn.Location = new Point(
                        x + cot * (rong + khoangX),
                        y + dong * (cao + khoangY));

                    btn.FlatStyle = FlatStyle.Standard;
                    btn.BackColor = SystemColors.Control;
                    btn.TabStop = false;

                    if (btn.Text == "=")
                        btn.Click += btnBang_Click;
                    else if (btn.Text == "C")
                        btn.Click += btnXoa_Click;
                    else if (btn.Text == "+" ||
                             btn.Text == "-" ||
                             btn.Text == "*" ||
                             btn.Text == "/")
                        btn.Click += btnPhepTinh_Click;
                    else
                        btn.Click += btnSo_Click;

                    Controls.Add(btn);
                }
            }
        }

        // Xử lý khi nhấn phím trên bàn phím máy tính
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Nếu là số
            if (char.IsDigit(e.KeyChar))
            {
                Button btnGiaLap = new Button();
                btnGiaLap.Text = e.KeyChar.ToString();
                btnSo_Click(btnGiaLap, null);
            }
            // Nếu là phép tính
            else if (e.KeyChar == '+' || e.KeyChar == '-' || e.KeyChar == '*' || e.KeyChar == '/')
            {
                Button btnGiaLap = new Button();
                btnGiaLap.Text = e.KeyChar.ToString();
                btnPhepTinh_Click(btnGiaLap, null);
            }
            // Nếu là phím Enter hoặc phím '='
            else if (e.KeyChar == (char)Keys.Enter || e.KeyChar == '=')
            {
                btnBang_Click(null, null);
            }
            // Nếu là phím C (xóa)
            else if (char.ToUpper(e.KeyChar) == 'C' || e.KeyChar == (char)Keys.Escape)
            {
                btnXoa_Click(null, null);
            }
        }

        private void btnSo_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (batDauNhapSoMoi || txtHienThi.Text == "0")
            {
                txtHienThi.Text = btn.Text;
                batDauNhapSoMoi = false;
            }
            else
            {
                txtHienThi.Text += btn.Text;
            }
        }

        private void btnPhepTinh_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (!double.TryParse(txtHienThi.Text, out soThuNhat))
                return;

            phepTinh = btn.Text;
            batDauNhapSoMoi = true;
        }

        private void btnBang_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtHienThi.Text, out double soThuHai))
                return;

            double ketQua;

            switch (phepTinh)
            {
                case "+":
                    ketQua = soThuNhat + soThuHai;
                    break;
                case "-":
                    ketQua = soThuNhat - soThuHai;
                    break;
                case "*":
                    ketQua = soThuNhat * soThuHai;
                    break;
                case "/":
                    if (soThuHai == 0)
                    {
                        MessageBox.Show(
                            "Không thể chia cho 0!",
                            "Lỗi",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);

                        btnXoa_Click(null, null);
                        return;
                    }
                    ketQua = soThuNhat / soThuHai;
                    break;
                default:
                    return;
            }

            txtHienThi.Text = ketQua.ToString();
            soThuNhat = ketQua;
            phepTinh = "";
            batDauNhapSoMoi = true;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtHienThi.Text = "0";
            soThuNhat = 0;
            phepTinh = "";
            batDauNhapSoMoi = true;
        }
    }
}