using System;
using System.Drawing;
using System.Windows.Forms;

namespace KhachSanThanhThanh
{
    public partial class Form1 : Form
    {
        TextBox txtHoTen;
        TextBox txtDiaChi;
        TextBox txtSoNgay;
        TextBox txtThanhTien;
        TextBox txtSoLuotNguoi;
        TextBox txtTongSoTien;

        RadioButton radPhongDon;
        RadioButton radPhongDoi;
        RadioButton radPhongBa;

        CheckBox chkTivi;
        CheckBox chkInternet;
        CheckBox chkMayNuocNong;
        CheckBox chkKaraoke;
        CheckBox chkAnSang;

        Button btnThanhToan;
        Button btnNhapMoi;
        Button btnTongKet;
        Button btnThoat;

        decimal tongTien = 0;
        int tongSoLuotNguoi = 0;

        public Form1()
        {
            InitializeComponent();
            TaoGiaoDien();
            GanSuKien();
        }

        private void TaoGiaoDien()
        {
            Text = "frmDangKyKS";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(700, 325);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = true;

            Label lblTieuDe = new Label();
            lblTieuDe.Text = "KHÁCH SẠN THANH THANH - TRẢ PHÒNG";
            lblTieuDe.Font = new Font("Arial", 16F, FontStyle.Bold);
            lblTieuDe.ForeColor = Color.DarkOrange;
            lblTieuDe.AutoSize = false;
            lblTieuDe.TextAlign = ContentAlignment.MiddleCenter;
            lblTieuDe.Location = new Point(10, 5);
            lblTieuDe.Size = new Size(680, 40);
            Controls.Add(lblTieuDe);

            Panel panelTrai = new Panel();
            panelTrai.Location = new Point(7, 60);
            panelTrai.Size = new Size(405, 255);
            panelTrai.BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(panelTrai);

            Panel panelPhai = new Panel();
            panelPhai.Location = new Point(418, 60);
            panelPhai.Size = new Size(270, 255);
            panelPhai.BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(panelPhai);

            Label lblHoTen = new Label();
            lblHoTen.Text = "Họ và tên:";
            lblHoTen.Location = new Point(28, 25);
            lblHoTen.AutoSize = true;
            panelTrai.Controls.Add(lblHoTen);

            txtHoTen = new TextBox();
            txtHoTen.Location = new Point(106, 21);
            txtHoTen.Size = new Size(196, 23);
            panelTrai.Controls.Add(txtHoTen);

            Label lblDiaChi = new Label();
            lblDiaChi.Text = "Địa chỉ:";
            lblDiaChi.Location = new Point(28, 59);
            lblDiaChi.AutoSize = true;
            panelTrai.Controls.Add(lblDiaChi);

            txtDiaChi = new TextBox();
            txtDiaChi.Location = new Point(106, 55);
            txtDiaChi.Size = new Size(300, 23);
            panelTrai.Controls.Add(txtDiaChi);

            Label lblSoNgay = new Label();
            lblSoNgay.Text = "Số ngày ở:";
            lblSoNgay.Location = new Point(28, 94);
            lblSoNgay.AutoSize = true;
            panelTrai.Controls.Add(lblSoNgay);

            txtSoNgay = new TextBox();
            txtSoNgay.Location = new Point(106, 90);
            txtSoNgay.Size = new Size(81, 23);
            txtSoNgay.TextAlign = HorizontalAlignment.Right;
            panelTrai.Controls.Add(txtSoNgay);

            GroupBox grpLoaiPhong = new GroupBox();
            grpLoaiPhong.Text = "Loại phòng";
            grpLoaiPhong.Location = new Point(15, 119);
            grpLoaiPhong.Size = new Size(115, 135);
            panelTrai.Controls.Add(grpLoaiPhong);

            radPhongDon = new RadioButton();
            radPhongDon.Text = "Phòng đơn";
            radPhongDon.Location = new Point(10, 25);
            radPhongDon.AutoSize = true;
            grpLoaiPhong.Controls.Add(radPhongDon);

            radPhongDoi = new RadioButton();
            radPhongDoi.Text = "Phòng đôi";
            radPhongDoi.Location = new Point(10, 57);
            radPhongDoi.AutoSize = true;
            grpLoaiPhong.Controls.Add(radPhongDoi);

            radPhongBa = new RadioButton();
            radPhongBa.Text = "Phòng ba";
            radPhongBa.Location = new Point(10, 89);
            radPhongBa.AutoSize = true;
            grpLoaiPhong.Controls.Add(radPhongBa);

            GroupBox grpTienNghi = new GroupBox();
            grpTienNghi.Text = "Tiện nghi";
            grpTienNghi.Location = new Point(135, 119);
            grpTienNghi.Size = new Size(135, 135);
            panelTrai.Controls.Add(grpTienNghi);

            chkTivi = new CheckBox();
            chkTivi.Text = "Tivi";
            chkTivi.Location = new Point(10, 25);
            chkTivi.AutoSize = true;
            grpTienNghi.Controls.Add(chkTivi);

            chkInternet = new CheckBox();
            chkInternet.Text = "Internet";
            chkInternet.Location = new Point(10, 57);
            chkInternet.AutoSize = true;
            grpTienNghi.Controls.Add(chkInternet);

            chkMayNuocNong = new CheckBox();
            chkMayNuocNong.Text = "Máy nước nóng";
            chkMayNuocNong.Location = new Point(10, 89);
            chkMayNuocNong.AutoSize = true;
            grpTienNghi.Controls.Add(chkMayNuocNong);

            GroupBox grpDichVu = new GroupBox();
            grpDichVu.Text = "Dịch vụ";
            grpDichVu.Location = new Point(275, 119);
            grpDichVu.Size = new Size(115, 135);
            panelTrai.Controls.Add(grpDichVu);

            chkKaraoke = new CheckBox();
            chkKaraoke.Text = "Karaoke";
            chkKaraoke.Location = new Point(10, 25);
            chkKaraoke.AutoSize = true;
            grpDichVu.Controls.Add(chkKaraoke);

            chkAnSang = new CheckBox();
            chkAnSang.Text = "Ăn sáng";
            chkAnSang.Location = new Point(10, 57);
            chkAnSang.AutoSize = true;
            grpDichVu.Controls.Add(chkAnSang);

            btnThanhToan = new Button();
            btnThanhToan.Text = "Thanh toán";
            btnThanhToan.Location = new Point(15, 18);
            btnThanhToan.Size = new Size(95, 27);
            btnThanhToan.UseVisualStyleBackColor = true;
            panelPhai.Controls.Add(btnThanhToan);

            btnNhapMoi = new Button();
            btnNhapMoi.Text = "Nhập mới";
            btnNhapMoi.Location = new Point(115, 18);
            btnNhapMoi.Size = new Size(90, 27);
            btnNhapMoi.UseVisualStyleBackColor = true;
            panelPhai.Controls.Add(btnNhapMoi);

            Label lblThanhTien = new Label();
            lblThanhTien.Text = "Thành tiền:";
            lblThanhTien.Location = new Point(15, 57);
            lblThanhTien.AutoSize = true;
            panelPhai.Controls.Add(lblThanhTien);

            txtThanhTien = new TextBox();
            txtThanhTien.Location = new Point(95, 54);
            txtThanhTien.Size = new Size(162, 23);
            txtThanhTien.ReadOnly = true;
            panelPhai.Controls.Add(txtThanhTien);

            btnTongKet = new Button();
            btnTongKet.Text = "Tổng Kết";
            btnTongKet.Location = new Point(15, 94);
            btnTongKet.Size = new Size(87, 27);
            btnTongKet.UseVisualStyleBackColor = true;
            panelPhai.Controls.Add(btnTongKet);

            Label lblThongTin = new Label();
            lblThongTin.Text = "Thông tin tổng kết";
            lblThongTin.Location = new Point(15, 130);
            lblThongTin.AutoSize = true;
            panelPhai.Controls.Add(lblThongTin);

            Label lblSoLuotNguoi = new Label();
            lblSoLuotNguoi.Text = "Số lượt người:";
            lblSoLuotNguoi.Location = new Point(15, 159);
            lblSoLuotNguoi.AutoSize = true;
            panelPhai.Controls.Add(lblSoLuotNguoi);

            txtSoLuotNguoi = new TextBox();
            txtSoLuotNguoi.Location = new Point(120, 156);
            txtSoLuotNguoi.Size = new Size(137, 23);
            txtSoLuotNguoi.ReadOnly = true;
            panelPhai.Controls.Add(txtSoLuotNguoi);

            Label lblTongSoTien = new Label();
            lblTongSoTien.Text = "Tổng số tiền:";
            lblTongSoTien.Location = new Point(15, 193);
            lblTongSoTien.AutoSize = true;
            panelPhai.Controls.Add(lblTongSoTien);

            txtTongSoTien = new TextBox();
            txtTongSoTien.Location = new Point(120, 190);
            txtTongSoTien.Size = new Size(137, 23);
            txtTongSoTien.ReadOnly = true;
            panelPhai.Controls.Add(txtTongSoTien);

            btnThoat = new Button();
            btnThoat.Text = "Thoát";
            btnThoat.Location = new Point(15, 222);
            btnThoat.Size = new Size(87, 27);
            btnThoat.UseVisualStyleBackColor = true;
            panelPhai.Controls.Add(btnThoat);

            // Trạng thái ban đầu
            btnThanhToan.Enabled = false;
            btnNhapMoi.Enabled = false;
            btnTongKet.Enabled = false;
            btnThoat.Enabled = true;

            txtHoTen.Focus();
        }

        private void GanSuKien()
        {
            txtHoTen.TextChanged += KiemTraThongTin;
            txtDiaChi.TextChanged += KiemTraThongTin;
            txtSoNgay.TextChanged += KiemTraThongTin;

            radPhongDon.CheckedChanged += KiemTraThongTin;
            radPhongDoi.CheckedChanged += KiemTraThongTin;
            radPhongBa.CheckedChanged += KiemTraThongTin;

            btnThanhToan.Click += btnThanhToan_Click;
            btnNhapMoi.Click += btnNhapMoi_Click;
            btnTongKet.Click += btnTongKet_Click;
            btnThoat.Click += btnThoat_Click;
        }

        private void KiemTraThongTin(object sender, EventArgs e)
        {
            int soNgay;

            bool hoTenHopLe = !string.IsNullOrWhiteSpace(txtHoTen.Text);
            bool diaChiHopLe = !string.IsNullOrWhiteSpace(txtDiaChi.Text);
            bool soNgayHopLe = int.TryParse(txtSoNgay.Text, out soNgay) && soNgay > 0;
            bool phongHopLe = radPhongDon.Checked ||
                              radPhongDoi.Checked ||
                              radPhongBa.Checked;

            btnThanhToan.Enabled =
                hoTenHopLe &&
                diaChiHopLe &&
                soNgayHopLe &&
                phongHopLe;
        }

        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            if (!KiemTraDuLieu())
                return;

            int soNgay = int.Parse(txtSoNgay.Text);

            decimal tienPhong = 0;
            int soNguoi = 0;

            if (radPhongDon.Checked)
            {
                tienPhong = 300000 * soNgay;
                soNguoi = 1;
            }
            else if (radPhongDoi.Checked)
            {
                tienPhong = 350000 * soNgay;
                soNguoi = 2;
            }
            else if (radPhongBa.Checked)
            {
                tienPhong = 400000 * soNgay;
                soNguoi = 3;
            }

            int soTienNghi = 0;

            if (chkTivi.Checked)
                soTienNghi += 10000;

            if (chkInternet.Checked)
                soTienNghi += 10000;

            if (chkMayNuocNong.Checked)
                soTienNghi += 10000;

            decimal tienDichVu = 0;

            if (chkKaraoke.Checked)
                tienDichVu += 50000;

            if (chkAnSang.Checked)
                tienDichVu += 15000 * soNgay;

            decimal thanhTien = tienPhong + soTienNghi + tienDichVu;

            txtThanhTien.Text = thanhTien.ToString("N0") + " VNĐ";

            tongTien += thanhTien;
            tongSoLuotNguoi += soNguoi;

            btnThanhToan.Enabled = false;
            btnNhapMoi.Enabled = true;
            btnTongKet.Enabled = true;
        }

        private bool KiemTraDuLieu()
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show(
                    "Tên khách hàng không được để trống!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtHoTen.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtDiaChi.Text))
            {
                MessageBox.Show(
                    "Địa chỉ không được để trống!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtDiaChi.Focus();
                return false;
            }

            int soNgay;

            if (!int.TryParse(txtSoNgay.Text, out soNgay) || soNgay <= 0)
            {
                MessageBox.Show(
                    "Số ngày ở phải là số nguyên lớn hơn 0!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtSoNgay.Focus();
                return false;
            }

            if (!radPhongDon.Checked &&
                !radPhongDoi.Checked &&
                !radPhongBa.Checked)
            {
                MessageBox.Show(
                    "Vui lòng chọn loại phòng!",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            return true;
        }

        private void btnNhapMoi_Click(object sender, EventArgs e)
        {
            txtHoTen.Clear();
            txtDiaChi.Clear();
            txtSoNgay.Clear();

            txtThanhTien.Clear();

            radPhongDon.Checked = false;
            radPhongDoi.Checked = false;
            radPhongBa.Checked = false;

            chkTivi.Checked = false;
            chkInternet.Checked = false;
            chkMayNuocNong.Checked = false;

            chkKaraoke.Checked = false;
            chkAnSang.Checked = false;

            btnThanhToan.Enabled = false;
            btnNhapMoi.Enabled = false;

            txtHoTen.Focus();
        }

        private void btnTongKet_Click(object sender, EventArgs e)
        {
            txtSoLuotNguoi.Text = tongSoLuotNguoi.ToString();
            txtTongSoTien.Text = tongTien.ToString("N0") + " VNĐ";

            tongSoLuotNguoi = 0;
            tongTien = 0;

            btnTongKet.Enabled = false;
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult ketQua = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát khỏi chương trình không?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (ketQua == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}